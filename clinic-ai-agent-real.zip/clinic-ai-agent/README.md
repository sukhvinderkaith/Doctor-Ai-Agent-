# Clinic AI Receptionist

Real backend starter for a clinic AI receptionist.

## What it does
- Uses OpenAI Responses API for the conversation.
- Uses function calling to create appointments.
- Stores appointments/patients/messages in SQLite.
- Provides a Meta WhatsApp webhook.
- Sends WhatsApp replies through the WhatsApp Cloud API.
- Includes `/test-chat` for testing before WhatsApp is connected.

## Setup
1. Install Node.js 20+.
2. Run:
   npm install
3. Copy `.env.example` to `.env`.
4. Add your OpenAI API key.
5. Start:
   npm start
6. Test locally:
   POST http://localhost:3000/test-chat
   JSON: {"phone":"demo","message":"Mujhe kal appointment chahiye"}

## WhatsApp
Create/configure a WhatsApp Business Platform app in Meta, then set:
- WHATSAPP_VERIFY_TOKEN
- WHATSAPP_ACCESS_TOKEN
- WHATSAPP_PHONE_NUMBER_ID
- GRAPH_API_VERSION

Expose `/webhook` over HTTPS and use its GET URL as the Meta webhook callback. Subscribe to the WhatsApp messages webhook.

## Important
This is an MVP, not a medical system. Do not use it for diagnosis or prescriptions. Before commercial deployment, add authentication, encrypted/controlled data storage, audit logging, consent/privacy notices, appointment conflict/time-zone validation, rate limiting, monitoring, backups and appropriate legal/compliance review for the jurisdiction and clinic.
