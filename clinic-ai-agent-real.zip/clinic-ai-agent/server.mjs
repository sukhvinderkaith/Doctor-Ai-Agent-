import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";
import Database from "better-sqlite3";

dotenv.config();
const app = express();
app.use(express.json());

const db = new Database("clinic.db");
db.exec(`
CREATE TABLE IF NOT EXISTS patients (
  phone TEXT PRIMARY KEY,
  name TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS appointments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  phone TEXT NOT NULL,
  patient_name TEXT,
  doctor TEXT NOT NULL,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  status TEXT DEFAULT 'confirmed',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  phone TEXT,
  direction TEXT,
  text TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const clinic = {
  name: process.env.CLINIC_NAME || "Sharma Clinic",
  doctor: process.env.DOCTOR_NAME || "Dr. Sharma",
  fee: process.env.CONSULTATION_FEE || "500",
  timing: process.env.CLINIC_TIMING || "10:00 AM-1:00 PM and 5:00 PM-8:00 PM",
  address: process.env.CLINIC_ADDRESS || "Your clinic address",
  offDays: process.env.CLINIC_OFF_DAYS || "Sunday"
};

const SYSTEM = `
You are the AI receptionist for ${clinic.name}.
Doctor: ${clinic.doctor}
Consultation fee: ₹${clinic.fee}
Clinic timing: ${clinic.timing}
Weekly off: ${clinic.offDays}
Address: ${clinic.address}

Your job is ONLY reception/appointment assistance:
- greet patients
- answer clinic timing, fee and address questions
- collect appointment details
- help with appointment booking
- never diagnose, prescribe, interpret test results, or recommend medicines
- if a patient asks for medical advice, say that a doctor must evaluate them
- for emergency symptoms, tell them to seek immediate local emergency medical care
- never invent availability, fees, services, doctors or medical facts
- be concise, polite and comfortable in Hindi/Hinglish/English
- if the user wants an appointment, collect: patient name, preferred date and preferred time.
- Once all details are known, call book_appointment.
`;

const tools = [{
  type: "function",
  name: "book_appointment",
  description: "Book a clinic appointment after the patient has supplied their name, date and preferred time.",
  strict: true,
  parameters: {
    type: "object",
    properties: {
      patient_name: {type: "string"},
      date: {type: "string", description: "Date in YYYY-MM-DD"},
      time: {type: "string", description: "Requested appointment time, e.g. 17:30"}
    },
    required: ["patient_name", "date", "time"],
    additionalProperties: false
  }
}];

function isSlotTaken(date, time) {
  return !!db.prepare(
    "SELECT 1 FROM appointments WHERE date=? AND time=? AND status='confirmed'"
  ).get(date, time);
}

function bookAppointment(phone, args) {
  if (isSlotTaken(args.date, args.time)) {
    return {ok:false, message:"That slot is already booked. Please offer another time."};
  }
  db.prepare(
    "INSERT INTO appointments(phone,patient_name,doctor,date,time) VALUES(?,?,?,?,?)"
  ).run(phone, args.patient_name, clinic.doctor, args.date, args.time);
  db.prepare(
    "INSERT INTO patients(phone,name) VALUES(?,?) ON CONFLICT(phone) DO UPDATE SET name=excluded.name"
  ).run(phone, args.patient_name);
  return {ok:true, message:`Appointment confirmed for ${args.patient_name} with ${clinic.doctor} on ${args.date} at ${args.time}.`};
}

async function aiReply(phone, userText) {
  db.prepare("INSERT INTO messages(phone,direction,text) VALUES(?,?,?)")
    .run(phone, "in", userText);

  const history = db.prepare(
    "SELECT direction,text FROM messages WHERE phone=? ORDER BY id DESC LIMIT 12"
  ).all(phone).reverse();

  let input = history.map(m => ({
    role: m.direction === "in" ? "user" : "assistant",
    content: m.text
  }));

  let response = await openai.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
    instructions: SYSTEM,
    tools,
    input
  });

  for (const item of response.output || []) {
    if (item.type === "function_call" && item.name === "book_appointment") {
      const args = JSON.parse(item.arguments);
      const result = bookAppointment(phone, args);
      response = await openai.responses.create({
        model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
        instructions: SYSTEM,
        tools,
        input: [
          ...input,
          ...response.output,
          {type:"function_call_output", call_id:item.call_id, output:JSON.stringify(result)}
        ]
      });
    }
  }

  const text = response.output_text || "कृपया थोड़ी देर बाद दोबारा प्रयास करें।";
  db.prepare("INSERT INTO messages(phone,direction,text) VALUES(?,?,?)")
    .run(phone, "out", text);
  return text;
}

async function sendWhatsApp(to, text) {
  const token = process.env.WHATSAPP_ACCESS_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  const version = process.env.GRAPH_API_VERSION || "v23.0";
  if (!token || !phoneId) throw new Error("WhatsApp credentials are not configured.");

  const r = await fetch(`https://graph.facebook.com/${version}/${phoneId}/messages`, {
    method:"POST",
    headers:{
      "Authorization":`Bearer ${token}`,
      "Content-Type":"application/json"
    },
    body:JSON.stringify({
      messaging_product:"whatsapp",
      to,
      type:"text",
      text:{body:text}
    })
  });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

// Health check
app.get("/", (_,res) => res.json({
  ok:true,
  service:"Clinic AI Receptionist",
  clinic:clinic.name,
  whatsappConfigured:!!process.env.WHATSAPP_ACCESS_TOKEN
}));

// Meta webhook verification
app.get("/webhook", (req,res) => {
  const mode=req.query["hub.mode"];
  const token=req.query["hub.verify_token"];
  const challenge=req.query["hub.challenge"];
  if(mode==="subscribe" && token===process.env.WHATSAPP_VERIFY_TOKEN) return res.status(200).send(challenge);
  return res.sendStatus(403);
});

// Meta webhook receiver
app.post("/webhook", async (req,res) => {
  res.sendStatus(200);
  try {
    const changes=req.body?.entry?.[0]?.changes?.[0]?.value;
    const msg=changes?.messages?.[0];
    if(!msg || msg.type!=="text") return;
    const from=msg.from;
    const reply=await aiReply(from,msg.text.body);
    await sendWhatsApp(from,reply);
  } catch(e) {
    console.error("Webhook error:",e.message);
  }
});

// Local test endpoint: POST {"phone":"demo","message":"appointment chahiye"}
app.post("/test-chat", async (req,res) => {
  try {
    const phone=String(req.body.phone || "demo");
    const message=String(req.body.message || "");
    const reply=await aiReply(phone,message);
    res.json({reply});
  } catch(e) {
    res.status(500).json({error:e.message});
  }
});

app.get("/appointments", (_,res) => {
  res.json(db.prepare("SELECT * FROM appointments ORDER BY date,time").all());
});

app.listen(process.env.PORT || 3000, () =>
  console.log(`Clinic AI Agent running on port ${process.env.PORT || 3000}`)
);
